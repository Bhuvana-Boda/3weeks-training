def fun(s):
    fc=s.count("m")
    mc=s.count("f")
    if mc==fc:
        print(0)
    elif mc>fc:
        print("m")
    else:
        print("f")
print(fun("mmffmmffffmmmfffff"))



