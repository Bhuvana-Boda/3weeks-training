'''def decode(encoded, first):
    n = len(encoded) + 1
    arr = [0] * n
    arr[0] = first
    
    for i in range(1, n):
        arr[i] = encoded[i-1] ^ arr[i-1]
    
    return arr
encoded = [1, 2, 3]
first = 1
print(decode(encoded, first))

encoded = [6, 2, 7, 3]
first = 4
print(decode(encoded, first))


'''
encoded = [1, 2, 3]
first = 1 
a = [first]
for i in range(len(encoded)):
    a.append(a[i] ^ encoded[i])
print(a)
