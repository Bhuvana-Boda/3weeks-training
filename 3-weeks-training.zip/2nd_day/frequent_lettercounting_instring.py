s="mfmff"
c=0
for i in s:
    if i=="m":
        c=c+1
    else:
        c=c-1
if c==0:
    print("o")
elif c==1:
    print("m")
else:
    print("f")