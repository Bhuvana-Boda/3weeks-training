t="leet**cod*e"
u=[]
for i in t:
    if(i!='*'):
        u.append(i)
    else:
        u.pop()
print(''.join(u))