'''def fun(x):
    print(x)
    fun(x+1)
fun(1)'''

'''def fun(x):
    if(x==6):
        return
    print(x)
    fun(x+1)
    print(x)
fun(1)
print("hii")'''

'''def fun(x):
    return x+10
print(fun(5))'''

'''def fun(x):
    return 400
print(fun(10))'''

'''def fun(x):
    if(x==6):
        return 500
    print(x)
    fun(x+1)
    print(x)
print(fun(1))'''

def fun(x):
    if(x==4):
        return 500
    print(x)
    fun(x+1)
    print(x)
    return 100
print(fun(1))