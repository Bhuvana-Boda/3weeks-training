a=[10,4,8,3]
b=[]
for i in range(len(a)):
    b.append(abs(sum(a[:i])-sum(a[i+1:])))
print(b)

'''class Solution:
    def leftRightDifference(self, nums: List[int]) -> List[int]:
        res = []

        for i in range(len(nums)):
            res.append(abs(sum(nums[0:i])-sum(nums[i+1:])))
        return res'''