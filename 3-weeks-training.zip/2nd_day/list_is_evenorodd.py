n=[2,4,6,3]
if(len(n)%2==0):
    print("even")
else:
    print("odd")
