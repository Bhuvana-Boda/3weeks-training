''' write a program to print the length of longest substring without repeating characters
    ip:  "abfgresagtyuiofde"
    op: 12
'''
def sub_string(s):
    start = 0
    max_length = 0
    max_substring = ""
    set = {}

    for i in range(len(s)):
        char = s[i]
        if char in set and set[char] >= start:
            start = set[char] + 1
        set[char] = i
        if i - start + 1 > max_length:
            max_length = i - start + 1
            max_substring = s[start:i + 1]

    return max_substring

str = "abfgresagtyuiofde"
print(sub_string(str))
print(len(sub_string(str)))
