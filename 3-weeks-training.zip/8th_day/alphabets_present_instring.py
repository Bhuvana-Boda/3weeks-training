''' find if all the alphabets are present or not in a given string
  ip:
           "the quick brown fox jumbs over the lazy dog"
   op:
          yes
     ip:
           "the 4quick br&%own fox jumENDbs o.ver the lazy dog"
   op:
          yes'''


s= "the quick brown fox jumps over the lazy dog"
a = set(s.lower())
if(len(a)<=27):
    print("yes")
else:
    print("no")

#lowercase
'''a=input()
d={}
for i in a:
    if(i.islower()):
        if(i not in d):
            d[i]=1
print(d)'''

#set
'''a=input()
d=set()
for i in a:
    if(i.islower()):
        if(i not in d):
            d.add(i)
print(d)'''

#dictionaries

'''a= input()
d=[0]*26

for i in a:
    if(i.islower()):
        d[ord(i)-97]+=1
print(d)'''

#all alphabets

'''a= input()
d=[0]*26

for i in a:
    if(i.islower()):
        d[ord(i)-97]+=1
print(all(d))'''
