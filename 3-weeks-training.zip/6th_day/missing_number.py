class Solution:
    def missingNumber(self, nums: List[int]) -> int:
        b=sum(nums)
        n=len(nums)
        n=(n*(n+1))//2
        return n-b
        