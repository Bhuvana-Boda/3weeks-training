class Solution:
    def majorityElement(self, nums: List[int]) -> int:
        c=1
        p=nums[0]
        for i in range(len(nums)):
            if(nums[i])==p:
                c=c+1
            else:
                c=c-1
                if c==0:
                    c=1
                    p=nums[i]
        return p
        