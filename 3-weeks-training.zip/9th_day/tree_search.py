class Node:
    def __init__(self, u):
        self.data = u
        self.left = None
        self.right = None
class Tree:
    def __init__(self):
        self.root = None
    def create(self, root, x):
        if root is None:
            return Node(x)
        elif x < root.data:
            root.left = self.create(root.left, x)
        else:
            root.right = self.create(root.right, x)
        return root

    def insert(self, x):
        self.root = self.create(self.root, x)
    def search(self,root,key):
        if (root== None) or root.data == key:
            return root
        if key < root.data:
            return self.search(root.left, key)
        return self.search(root.right, key)
        result = self.search(self.root, key)
    def search_element(self,key):
        result = self.search(self.root, key)
        if result:
            print(f"Element {key} is found in the tree.")
        else:
            print(f"Element {key} is not found in the tree.")
    
t1 = Tree()
t1.insert(10)
t1.insert(5)
t1.insert(15)
t1.insert(7)
t1.insert(1)
t1.insert(3)
t1.insert(2)
search = 4
t1.search_element(search)



 





