class Node:
    def __init__(self, u):
        self.data = u
        self.left = None
        self.right = None
class Tree:
    def __init__(self):
        self.root = None
    def create(self, root, x):
        if root is None:
            return Node(x)
        elif x < root.data:
            root.left = self.create(root.left, x)
        else:
            root.right = self.create(root.right, x)
        return root

    def insert(self, x):
        self.root = self.create(self.root, x)
    def leftview(self,root,c,l):
        if(root==None):
            return
        if(c not in l):
            l.append(c)
            print(root.data)
        self.leftview(root.left,c+1,l)
        self.leftview(root.right,c+1,l)
    def rightview(self,root,c,l):
        if(root==None):
            return
        if(c not in l):
            l.append(c)
            print(root.data)
        self.rightview(root.right,c+1,l)
        self.rightview(root.left,c+1,l)
    '''def topview(self,root,c,dict1):
        if root==None:
            return 
        if c not in dict1:
            print(root.data)
            dict1.update({c:root.data})
        self.topview(root.left,c+1,dict1)  
        self.topview(root.right,c-1,dict1)'''
    def topview(self,root):
        if(root==None):
            return
        d={}
        q=[(root,0)]
        while(q):
            root = q[0][0]
            if(root.left!=None):
                q.append((root.left,q[0][1]-1))
            if(root.right!=None):
                q.append((root.right,q[0][1]+1))
            if(q[0][1] not in d):
                d[q[0][1]]=root.data
            q.pop(0)
        for i in sorted(d):
            print(d[i],end=" ")
    '''def bottomview(self,root,c,dict1):
        if root==None:
            return
        if c not in dict1:
            print(root.data)
            dict1.update({c:root.data})
        self.bottomview(root.left,c-1,dict1)
        self.bottomview(root.right,c+1,dict1)'''
    def bottomview(self,root):
        if(root==None):
            return
        d={}
        q=[(root,0)]
        while(q):
            root = q[0][0]
            if(root.left!=None):
                q.append((root.left,q[0][1]-1))
            if(root.right!=None):
                q.append((root.right,q[0][1]+1))
            d[q[0][1]]=root.data
            q.pop(0)
        for i in sorted(d):
            print(d[i],end=" ")
        
t1 = Tree()
t1.insert(10)
t1.insert(5)
t1.insert(15)
t1.insert(7)
t1.insert(11)
t1.insert(9)
t1.insert(2)
t1.insert(8)
print("leftview")
t1.leftview(t1.root,0,[])
print("topview")
t1.topview(t1.root)
print()
print("rightview")
t1.rightview(t1.root,0,[])
print("bottom view")
t1.bottomview(t1.root) 





 






