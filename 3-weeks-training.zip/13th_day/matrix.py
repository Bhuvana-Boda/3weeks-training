def find_paths(matrix, row, col, path):
    path.append((row, col))
    if row == len(matrix) - 1 and col == len(matrix[0]) - 1:
        print(path)
        path.pop()  
        return
    
    if col + 1 < len(matrix[0]):
        find_paths(matrix, row, col + 1, path)
    
    if row + 1 < len(matrix):
        find_paths(matrix, row + 1, col, path)

    path.pop()
matrix = [
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 10, 11, 12]]
find_paths(matrix, 0, 0, [])
