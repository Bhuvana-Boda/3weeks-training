''' consider the two string.. with n number input
    give output as lexicograpical order string(which letter comes first it prints that letter 1st)
   ip:
       2
       polikujmnhytgbvfredcxswqaz
       abcd
       qwryupcsfoghjkldezxvbintma
       --->ativedoc
       --->abbcdde
    op:
          bdca
          codevita
          eaddcbb
          '''
n=int(input())
while(n):
    a=input()
    c=input()
    s=''
    for i in a:
        if(i in c):
            s=s+(i*c.count(i))
    print(s)
    n=n-1
    
