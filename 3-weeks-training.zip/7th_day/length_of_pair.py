''''write a program to print 3 possible combinations in a list using recursion..........
    ip:   [3,2,5,4,1,6,8]
    op:
            3 2 5      35 4       3 4 1       3 1 6    3 6 8
            3 2 4      3 5 1       3 4 6    3 1 8
            3 2 1        3 5 6      3 4 8
            3 2 6       3 5 8
            3 2 8

            2 5 4   2 5 1       2 5 6   2 5 8'''

def comb(l,k):
    def fun(curr,start):
        if len(curr) == k:
            print(curr)
            return
        for i in range(start,len(l)):
            fun(curr+[l[i]],i+1)
    fun([],0)
a=[3,5,1,6,7]
k=4#length of pair mentioned..
comb(a,k)

    
