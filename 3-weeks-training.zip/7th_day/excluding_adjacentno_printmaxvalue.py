''' for the given input list find the sums of the numbers of max possible numbers excluding its adjacent number and print output as the max value of those sum of numbers
    ip:
        [13,9,4,10,5,7]
    op:
         22  26     30
         30...
         using recursion write a code        '''

def fun(l):
    if(len(l)==0):
        return 0
    if(len(l)==1):
        return l[0]
    if(len(l)==2):
       return max(l)
    le=l[0]+fun(l[2:])
    ri=l[1]+fun(l[3:])
    return max(le,ri)
l=[13,9,4,10,5,7]
print(fun(l))
