a=300
b=400
count=0
for i in range(a,b+1):
    if(i%7==0):
        count=count+1
print(count)

