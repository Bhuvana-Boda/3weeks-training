str="f46fjeefeweiknihsfi32@ejeb&^$"
lv=""
uv=""
lc=""
uc=""
d=""
s=""
lowercase_vowels="aeiou"
uppercase_vowels="AEIOU"
for char in str:
    if char in lowercase_vowels:
        lv +=char
    elif char in uppercase_vowels:
        uv +=char
    elif char.islower():
        lc +=char
    elif char.isupper():
        uc +=char
    elif char.isdigit():
        d +=char
    elif(not char.isalnum()):
        s +=char
print(len(lv))
print(len(uv))
print(len(lc))
print(len(uc))
print(len(d))
print(len(s))

'''
for i in a:
    if(i.isupper()):
        if(i in 'AEIOU'):
            uv=uv+1
        else:
            uc=uc+1
    elif(i.islower()):
        if(i in'aeiou'):
            lv=lv+1
        else:
            lc=lc+1
    elif(i.isdigit()):
'''

