def add_numbers(numbers):
    int_sum = 0
    float_sum = 0.0
    
    for number in numbers:
        if isinstance(number, int):
            int_sum += number
        elif isinstance(number, float):
            float_sum += number
    
    return int_sum, float_sum

numbers = [1, 2.5, 3, 4.75, 5]
int_sum, float_sum = add_numbers(numbers)
print(f"Sum of integers: {int_sum}")
print(f"Sum of floats: {float_sum}")
