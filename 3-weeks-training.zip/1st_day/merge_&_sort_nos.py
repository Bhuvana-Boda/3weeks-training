a=[1,5,8,9]
b=[2,7,9,10,14]
l1=len(a)
l2=len(b)
i=0
j=0
c=[]
while(i<len(a) and j<len(b)):
    if(a[i]<b[j]):
        c.append(a[i])
        i=i+1
    else:
        c.append(b[j])
        j=j+1
if(j<len(b)):
    c.extend(b[j:])
if(i<len(a)):
    c.extend(a[i:])
print(c)
        
       