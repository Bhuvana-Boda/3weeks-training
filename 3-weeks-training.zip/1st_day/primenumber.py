num=int(input("enter number:"))
while(1):
    c=0
    for i in range(2,(num//2)+1):
        if (num % i == 0):
            c=c+1
            break
    if(c==0):
        print(num)
        break
    else:
        num=num+1
print(num)
    
        