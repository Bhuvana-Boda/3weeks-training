"""str="placements"
for i in str:
    if("a"=="A" and "e"=="E" and "i"=="I" and "o"=="O" and "u"=="U"):
        print(str)"""
        
'''def convert(phrase):
    # Create a translation table for vowels
    vowel_trans = str.maketrans('aeiou','AEIOU')
    # Convert the entire phrase to uppercase and apply the translation
    return phrase.upper().translate(vowels_trans)

result = convert(str)
print("Converted phrase:", result)'''
def convert_vowels_to_uppercase(string):
    # Iterate through each character in the input string
    for i in range(len(string)):
        # Check if the character is a lowercase vowel
        if string[i] in ['a', 'e', 'i', 'o', 'u']:
            # Convert the lowercase vowel to uppercase in ASCII by subtracting 32
            string = string[:i] + chr(ord(string[i]) - 32) + string[i + 1:]
 
    return string
 
 
# Main function
if __name__ == "__main__":
    input_string = "placements"
    # Call the function to convert vowels to uppercase
    result_string = convert_vowels_to_uppercase(input_string)
    print(result_string)