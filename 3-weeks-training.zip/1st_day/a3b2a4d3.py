s= "aaabbaaaaddd"
b = ''
count = 1
for i in range(len(s)-1):
    if s[i] == s[i + 1]:
        count += 1
    else:
        b=b+s[i] + str(count)
        count = 1
b=b+s[-1] + str(count)
#b=b+s[i+1] + str(count)
print(b)
    