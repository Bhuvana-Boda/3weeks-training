l1=[1,3,5,6]
l2=[2,7,9,4]
l3=l1+l2
l3.sort()
print(l3)