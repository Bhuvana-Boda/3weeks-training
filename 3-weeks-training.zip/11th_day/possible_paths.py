def find_all_paths(d, start, end, path=[]):
    path = path + [start] 
    if start == end:
        return [path]
    if start not in d:
        return [] 
    paths = []  
    for node in d[start]: 
        if node not in path:  
            newpaths = find_all_paths(d, node, end, path)  
            for newpath in newpaths:
                paths.append(newpath)  
    return paths

d = {5: [7, 3], 7: [5, 4, 3], 4: [7, 8, 2], 8: [3, 4, 2], 3: [5, 7, 8], 2: [4, 8]}

all_paths = find_all_paths(d, 5, 2)
for path in all_paths:
    print(path)
all_paths = find_all_paths(d, 5, 7)
for path in all_paths:
    print(path)
    all_paths = find_all_paths(d, 5, 4)
for path in all_paths:
    print(path)
    all_paths = find_all_paths(d, 5, 8)
for path in all_paths:
    print(path)
    all_paths = find_all_paths(d, 5, 3)
for path in all_paths:
    print(path)