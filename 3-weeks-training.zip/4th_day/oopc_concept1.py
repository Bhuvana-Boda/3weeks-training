class qwer:
    def __init__(self,v,u):
        self.a=u
        self.b=v
    def asd(self):
        print("hello",self.a)
        x.zxc()
    def zxc(self):
        print("hi",self.b)
x=qwer(20,40)
y=qwer(50,10)
y.asd()