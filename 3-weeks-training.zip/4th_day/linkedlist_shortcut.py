class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def display(self):
        t=head
        while(t!=None):
            print(t.data)
            t=t.next
l1=sll()
head=node(10)
head.next=node(20)
head.next.next=node(30)
l1.display()
