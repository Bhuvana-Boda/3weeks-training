class A:
    def fun(self):
        print("hi")
class B(A):
    def fun(self):
        print("hey")
class C(B):
    def fun(self):
        print("hello")
class C(B,A):
    def fun1(self):
        print("hello")
x=C()
x.fun()