class qwer:
    def __init__(self,u,v):
        self.a=u
        self.b=v
    def asd(self,x):
        print("hello",self.a+x,self.b)
        y.zxc(x+10)
    def zxc(self,y):
        print("hi",self.b+y,self.a)
x=qwer(40,10)
y=qwer(50,10)
y.asd(60)

