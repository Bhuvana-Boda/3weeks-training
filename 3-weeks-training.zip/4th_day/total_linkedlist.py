class node:
    def __init__(self,u):
        self.data=u
        self.next=None
class sll:
    def __init__(self):
        self.head=None
    def display(self):
        t=self.head
        while(t!=None):
            print(t.data,end="->")
            t=t.next
    def addback(self,x):
        t=self.head
        while(t.next!=None):
            t=t.next
        t.next=node(x)
    def addeven(self):
        t=self.head
        s=0
        while(t!=None):
            if(t.data%2==0):
                s+=t.data
                t=t.next
        print(s)
    def search(self,x):
        t=self.head
        while(t!=None):
            if(t.data==x):
                return "found"
            t=t.next
        return "not found"
    def addmiddle_(self):
        F=self.head
        S=self.head
        while(F != None and F.next !=None):
            S=S.next
            F=F.next.next
        print(S.data)
    def length(self):
        F=self.head
        S=self.head
        while(F != None and F.next !=None):
            S=S.next                                               
            F=F.next.next
            if (F==None):
                print("even")
            else:
                print("odd")
        
    def allpairs(self):
         t=self.head
         while(t.next!=None):
             t1=t.next
             while(t1!=None):
                 print(t.data,t1.data)
                 t1=t1.next
             t=t.next
    def check(self):
        m=0
        c=0
        t=self.head
        while(t.next!=None):
            if(t.next.data-t.data !=1):
                c+=1
                t=t.next
            else:
                if c>m:
                    m=c                             
                c=1
            if c>m:
                m=c
        return m
    def bubblesort(self):
        c=0
        T=self.head
        p=None
        while(T.next!=None):
            f=0
            t=self.head
            while(t.next!=p):
                if(t.data>t.next.data):
                    f=1
                    t.data,t.next.data=t.next.data,t.data
                t=t.next
                c=c+1
            if(f==0):
                break
            p=t
            T=T.next
        return c
    def addfront(self,x):
        t=node(x)
        t.next=self.head
        self.head=t
                    
l1=sll()
l2=sll()
l1.head=node(10)
l1.addback(60)
l1.addback(30)
l1.addback(80)
l1.addback(40)
l2.head=node(100)
l2.addback(200)
l1.addback(300)
l1.addback(400)
l1.display()
print()
l2.display()
print()
l1.addeven()
print(l1.search(20))
#print(l1.addmiddle())
l1.length()
print(l1.allpairs())
l1.bubblesort()
l1.display()
print()
l1.addfront(5)
l1.display()
l1.check()


