'''def is_palindrome(num):
    original = num
    reversed = 0
    
    while num > 0:
        digit = num % 10
        reversed = reversed * 10 + digit
        num = num // 10
        
    return original == reversed

def next_palindrome(num):
    num += 1
    while not is_palindrome(num):
        num += 1
    return num'''


'''def next_palindrome(num):
    num_str = str(num)
    length = len(num_str)

    if length % 2 == 0:
        half_length = length // 2
        first_half = num_str[:half_length]
    else:
        half_length = length // 2
        first_half = num_str[:half_length + 1]
    incremented = int(first_half) + 1
    incremented_str = str(incremented)

    if length % 2 == 0:
        palindrome = incremented_str + reverse_string(incremented_str)
    else:
        palindrome = incremented_str + reverse_string(incremented_str[:-1])
    
    return int(palindrome)

def reverse_string(s):
    reversed_str = ''
    for char in s:
        reversed_str = char + reversed_str
    return reversed_str
num1 = 1234
num2 = 76583

next_pal1 = next_palindrome(num1)
next_pal2 = next_palindrome(num2)

print("Next palindrome after", num1, "is:", next_pal1)
print("Next palindrome after", num2, "is:", next_pal2)



user_input = int(input("Enter a number: "))

result = next_palindrome(user_input)
print("The next palindrome is:", result)'''
n=input()
if len(n)%2==0:
    t=n[0:len(n)//2]
    k=t+t[::-1]
    if k<n:
        t=t[:-1]+str(int(t[::-2])+1)
        k=t+t[::-1]
    print(k)
else:
    t=n[0:(len(n)//2)]
    k=t+(n[len(n)//2])+t[::-1]
    if k<n:
        a=str(int((n[len(n)//2]))+1)
        k=t+a+t[::-1]
        print(k)