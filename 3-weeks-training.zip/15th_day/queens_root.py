def queen(r):
    if(r==n):
        return
    if(r!=u):
        for c in range(n):
            if(check(r,c)):
                m[r][c]=1
                break
            m[r][c]=0
        return queen(r+1)
    else:
        queen(r+1)
def check(i,j):
    '''if(j==v):
        return 0
    r=i,c=j
    for i in range(r+1):
        if(m[i][j]==1):
            return 0
    i=r
    while(i>=0 and j>=0):
        if (m[r][j]==1):
            return 0
        i=i-1
        j=j-1
    while(r>=0 and c<n):
        if(m[r][c]==1):
            return 0
        r=r-1
        c=c+1'''
    for k in range(i):
        if m[k][j] == 1:
            return False
    r, c = i, j
    while r >= 0 and c >= 0:
        if m[r][c] == 1:
            return False
        r -= 1
        c -= 1
    r, c = i, j
    while r >= 0 and c < n:
        if m[r][c] == 1:
            return False
        r -= 1
        c += 1
    return True


n=6
u=2
v=3
m=[]
for i in range(n):
    m.append([0]*n)
queen(0)
print(m)

'''def queen(r):
    if r == n:
        print(m)
        return
    for c in range(n):
        if check(r, c):
            m[r][c] = 1
            queen(r + 1)
            m[r][c] = 0 

def check(i, j):
    for k in range(i):
        if m[k][j] == 1:
            return False
    r, c = i, j
    while r >= 0 and c >= 0:
        if m[r][c] == 1:
            return False
        r -= 1
        c -= 1
    r, c = i, j
    while r >= 0 and c < n:
        if m[r][c] == 1:
            return False
        r -= 1
        c += 1
    return True

n = 5
m = [[0]*n for i in range(n)]  
queen(0)'''


# max_queens
'''def queen(r):
    global max_queens
    if r == n:
        max_queens = max(max_queens, count_queens(m))
        return
    for c in range(n):
        if check(r, c):
            m[r][c] = 1
            queen(r + 1)
            m[r][c] = 0

def count_queens(m):
    count = 0
    for i in range(n):
        for j in range(n):
            if m[i][j] == 1:
                count += 1
    return count
def check(i, j):
    for k in range(i):
        if m[k][j] == 1:
            return False
    r, c = i, j
    while r >= 0 and c >= 0:
        if m[r][c] == 1:
            return False
        r -= 1
        c -= 1
    r, c = i, j
    while r >= 0 and c < n:
        if m[r][c] == 1:
            return False
        r -= 1
        c += 1
    return True
n = 4
m = [[0]*n for i in range(n)]
max_queens = 0
queen(0)
print(max_queens)'''