def fun(x):
    if(x==1):
        return 1
    if(x==2):
        return 2
    return fun(x-1)+fun(x-2)+x
print(fun(5))