'''print the pattern
*  *   *  *   *
*  1   2   3  *
*  4   5   6  *
*  7   8   9  *
*  *   *   *  *
'''
   
val=1
for i in range(5):
    for j in range(5):
        if i==0 or j==0 or i==4 or j==4:
            print("*",end=" ")
        else:
            print(val,end=" ")
            val+=1
    print(" ")  