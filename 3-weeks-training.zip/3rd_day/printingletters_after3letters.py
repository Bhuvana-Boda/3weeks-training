'''a=input()
b=int(input())
def fun(text, shift):
    c = ""
    for char in text:
        if char.isalpha():
            # Determine if the character is uppercase or lowercase
            d = ord('A') if char.isupper() else ord('a')
            # Shift the character and handle wrapping using modulo
            new_char = chr((ord(char) - d- b) % 26 + d)
            c += new_char
        else:
            c+= char  # Non-alphabetic characters are not shifted
    return c

c =fun(a,b)

print(c)'''

a='bvec'
b=30
c=b%26
d=''
for i in a:
    if((ord(i)-c)>=97):
        d=d+chr(ord(i)-c)
    else:
        d=d+chr(ord(i)-c+26)
print(d)

