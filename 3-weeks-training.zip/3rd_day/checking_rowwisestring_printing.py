"""using flag

n=int(input())
m=[]
for i in range(n):
    m.append(input())
s=input()
f=0
for i in range(len(s)):
    if(s[i] not in m[i]):
        continue
    else:
        f=1
        break
if(f==1):
    print('yes')
else:
    print('no')"""
    
n=int(input())
s=[]
k=0
for i in range(n):
    s.append(input())
ch=input()
for i in range(len(s)):
    if s[i] not in ch[i%n]:
        k=1
        print("False")
        break
    else:
        print("True")



















