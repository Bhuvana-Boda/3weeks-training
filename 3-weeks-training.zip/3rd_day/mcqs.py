a=[6,5,7,3,2]
a.append([5,8])
# extend does not work for integer ,it works only for strings
a.extend([4,2,1])
a.extend('7.8')
a.extend("hii")
print(len(a))

a={5,5.0,'5',3,2}
print(len(a))

a={5,5.0,'5',(5,2),'5,2',True}
print(a)
#list and set and dict is not allowed inside a set

a={5,5.0,'5',(5,2),'5,2',True,1,"hi",'hi',False}
print(a)