'''def longest_seq(s):
    max_len=0
    current_len=1
    for i in range(1,len(s)):
        if ord(s[i])==ord(s[i-1])+1:
            current_len+=1
        else:
            max_len=max(max_len,current_len)
            current_len=1
    max_len=max(max_len,current_len)
    return max_len
input_str="abcde"
longest_seq=longest_seq(input_str)
print(longest_seq)'''

a=input()
c=1
m=0
for i in range(len(a)-1):
    if(ord(a[i])==ord(a[i+1])-1):
        c=c+1
    else:
        if(c>m):
            m=c
        c=1
if(c>m):
   m=c
print(m)
        